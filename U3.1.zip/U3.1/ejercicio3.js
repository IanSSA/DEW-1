function addNumbers(){
    firstNum = 4;
    secondNum = 8;
    result = firstNum + secondNum;
    alert(result);
    return result;
}

result = 0;
alert(result);
sum = addNumbers();