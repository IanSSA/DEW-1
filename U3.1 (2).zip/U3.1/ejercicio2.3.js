function addNumbers(){
    let firstNum = 4;
    let secondNum = 8;
    let result = firstNum + secondNum;
    alert(result);
    return result;
}

result = 0;
alert(result);
sum = addNumbers();